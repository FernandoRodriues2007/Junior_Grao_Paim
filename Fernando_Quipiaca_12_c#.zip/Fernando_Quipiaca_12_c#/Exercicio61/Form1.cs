﻿using System;
using System.Windows.Forms;

namespace Exercicio61
{
    public partial class Form1 : Form
    {
        private TextBox txtAndares, txtEntraram, txtSairam;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int andares = 0;
        private int andarAtual = 0;
        private int pessoas = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 61";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Número de andares:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(150, 20);

            txtAndares = new TextBox();
            txtAndares.Location = new System.Drawing.Point(180, 20);
            txtAndares.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Pessoas entraram:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(150, 20);

            txtEntraram = new TextBox();
            txtEntraram.Location = new System.Drawing.Point(180, 50);
            txtEntraram.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Pessoas saíram:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(150, 20);

            txtSairam = new TextBox();
            txtSairam.Location = new System.Drawing.Point(180, 80);
            txtSairam.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add Andar";
            btnAdd.Location = new System.Drawing.Point(20, 120);
            btnAdd.Size = new System.Drawing.Size(150, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Iniciar";
            btnCalc.Location = new System.Drawing.Point(20, 160);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 210);
            lblRes.Size = new System.Drawing.Size(450, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtAndares);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtEntraram);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtSairam);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (andarAtual == 0)
                {
                    andares = int.Parse(txtAndares.Text);
                }
                int entraram = int.Parse(txtEntraram.Text);
                int sairam = int.Parse(txtSairam.Text);

                pessoas = pessoas + entraram - sairam;
                if (pessoas < 0) pessoas = 0;

                andarAtual++;
                if (andarAtual <= andares)
                {
                    if (pessoas > 15)
                    {
                        int excesso = pessoas - 15;
                        lblRes.Text = $"Res: EXCESSO DE PASSAGEIROS. DEVEM SAIR {excesso}";
                    }
                    else
                    {
                        lblRes.Text = $"Res: Andar {andarAtual}: {pessoas} pessoas";
                    }
                }

                if (andarAtual == andares)
                {
                    lblRes.Text += $"\nPessoas que irão descer: {pessoas}";
                    btnAdd.Enabled = false;
                }
                else
                {
                    txtEntraram.Text = "";
                    txtSairam.Text = "";
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            andarAtual = 0;
            pessoas = 0;
            btnAdd.Enabled = true;
            lblRes.Text = "Res: Iniciado";
        }
    }
}





