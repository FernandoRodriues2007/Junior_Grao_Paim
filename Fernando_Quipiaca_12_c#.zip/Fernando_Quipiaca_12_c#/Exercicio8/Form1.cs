﻿using System;
using System.Windows.Forms;

namespace Exercicio8
{
    public partial class Form1 : Form
    {
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 8";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 20);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 70);
            lblRes.Size = new System.Drawing.Size(450, 200);
            lblRes.AutoSize = false;

            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string res = "";
            for (int i = 1000; i <= 9999; i++)
            {
                int p1 = i / 100;
                int p2 = i % 100;
                int s = parte1 + parte2;
                if (soma * soma == i)
                {
                    if (resultado != "") resultado += ", ";
                    resultado += i;
                }
            }
            lblRes.Text = $"Res: {resultado}";
        }
    }
}





