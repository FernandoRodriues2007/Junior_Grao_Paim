﻿using System;
using System.Windows.Forms;

namespace Exercicio56
{
    public partial class Form1 : Form
    {
        private TextBox txtIdade, txtSexo, txtSal;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double somaSalario = 0;
        private int qtd = 0;
        private int maiorIdade = int.MinValue;
        private int menorIdade = int.MaxValue;
        private int mulheresSalario = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 56";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Idade (negativa para encerrar):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(200, 20);

            txtIdade = new TextBox();
            txtIdade.Location = new System.Drawing.Point(230, 20);
            txtIdade.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Sexo (M/F):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtSexo = new TextBox();
            txtSexo.Location = new System.Drawing.Point(130, 50);
            txtSexo.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Salário:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtSal = new TextBox();
            txtSal.Location = new System.Drawing.Point(130, 80);
            txtSal.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 120);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 160);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 210);
            lblRes.Size = new System.Drawing.Size(450, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtIdade);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtSexo);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtSal);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int idade = int.Parse(txtIdade.Text);
                if (idade < 0)
                {
                    btnCalc_Click(null, null);
                    return;
                }
                string sexo = txtSexo.Text.ToUpper();
                double sal = double.Parse(txtSal.Text);

                somaSalario += salario;
                qtd++;
                if (idade > maiorIdade) maiorIdade = idade;
                if (idade < menorIdade) menorIdade = idade;
                if (sexo == "F" && salario <= 100)
                    mulheresSalario++;

                txtIdade.Text = "";
                txtSexo.Text = "";
                txtSal.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (qtd > 0)
            {
                double med = somaSalario / qtd;
                lblRes.Text = $"Res:\na) Média salário: {med:F2}\nb) Maior idade: {maiorIdade}, Menor idade: {menorIdade}\nc) Mulheres salário <= 100: {mulheresSalario}";
            }
            else
            {
                lblRes.Text = "Res: Nenhum dado foi informado";
            }
        }
    }
}






