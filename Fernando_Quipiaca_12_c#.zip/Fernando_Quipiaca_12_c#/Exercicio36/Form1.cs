﻿using System;
using System.Windows.Forms;

namespace Exercicio36
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double[] numeros = new double[10];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 36";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite 10 números:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(20, 50);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(180, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 90);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Enabled = false;
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(350, 80);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                numeros[cont] = double.Parse(txtN.Text);
                cont++;
                txtN.Text = "";
                if (cont == 10)
                {
                    btnAdd.Enabled = false;
                    btnCalc.Enabled = true;
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double s = 0;
            double maior = numeros[0];
            double menor = numeros[0];
            for (int i = 0; i < 10; i++)
            {
                soma += numeros[i];
                if (numeros[i] > maior) maior = numeros[i];
                if (numeros[i] < menor) menor = numeros[i];
            }
            double med = s / 10;
            lblRes.Text = $"Res:\nMédia: {med:F2}\nMaior: {maior}\nMenor: {menor}";
        }
    }
}






