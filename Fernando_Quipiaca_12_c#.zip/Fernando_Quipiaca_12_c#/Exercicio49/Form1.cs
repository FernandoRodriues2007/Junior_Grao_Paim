﻿using System;
using System.Windows.Forms;

namespace Exercicio49
{
    public partial class Form1 : Form
    {
        private TextBox txtNome, txtDistancia, txtVisitantes, txtAcesso;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int totalHoteis = 0;
        private double somaDistancia = 0;
        private int qtdAcesso = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 49";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Nome do hotel:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(120, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(150, 20);
            txtNome.Size = new System.Drawing.Size(200, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Distância:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtDistancia = new TextBox();
            txtDistancia.Location = new System.Drawing.Point(130, 50);
            txtDistancia.Size = new System.Drawing.Size(100, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Visitantes:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtVisitantes = new TextBox();
            txtVisitantes.Location = new System.Drawing.Point(130, 80);
            txtVisitantes.Size = new System.Drawing.Size(100, 20);

            Label lbl4 = new Label();
            lbl4.Text = "Tipo acesso:";
            lbl4.Location = new System.Drawing.Point(20, 110);
            lbl4.Size = new System.Drawing.Size(100, 20);

            txtAcesso = new TextBox();
            txtAcesso.Location = new System.Drawing.Point(130, 110);
            txtAcesso.Size = new System.Drawing.Size(100, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 150);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 190);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 240);
            lblRes.Size = new System.Drawing.Size(450, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtNome);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtDistancia);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtVisitantes);
            this.Controls.Add(lbl4);
            this.Controls.Add(txtAcesso);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double distancia = double.Parse(txtDistancia.Text);
                int visitantes = int.Parse(txtVisitantes.Text);
                string acesso = txtAcesso.Text;

                totalHoteis++;
                somaDistancia += distancia;
                if (acesso.ToUpper() == "SIM" || acesso == "1")
                    qtdAcesso++;

                txtNome.Text = "";
                txtDistancia.Text = "";
                txtVisitantes.Text = "";
                txtAcesso.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (totalHoteis > 0)
            {
                double mediaDist = somaDistancia / totalHoteis;
                lblRes.Text = $"Res:\nMédia distância: {mediaDist:F2}\nCom acesso: {qtdAcesso}";
            }
            else
            {
                lblRes.Text = "Res: Nenhum hotel foi registrado";
            }
        }
    }
}





