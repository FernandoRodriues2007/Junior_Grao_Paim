﻿using System;
using System.Windows.Forms;

namespace Exercicio1
{
    public partial class Form1 : Form
    {
        private TextBox txtSeg;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 1";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblSeg = new Label();
            lblSeg.Text = "Segundos:";
            lblSeg.Location = new System.Drawing.Point(20, 20);
            lblSeg.Size = new System.Drawing.Size(150, 20);

            txtSeg = new TextBox();
            txtSeg.Location = new System.Drawing.Point(180, 20);
            txtSeg.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lblSeg);
            this.Controls.Add(txtSeg);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int seg = int.Parse(txtSeg.Text);
                int h = seg / 3600;
                int m = (seg % 3600) / 60;
                int s = seg % 60;
                lblRes.Text = $"Res: {h}h {m}min {s}s";
            }
            catch
            {
                lblRes.Text = "Res: Erro";
            }
        }
    }
}





