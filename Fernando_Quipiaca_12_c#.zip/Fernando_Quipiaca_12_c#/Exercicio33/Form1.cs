﻿using System;
using System.Windows.Forms;

namespace Exercicio33
{
    public partial class Form1 : Form
    {
        private TextBox txtIdade, txtAltura;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double somaIdade = 0, somaAltura = 0;
        private int qtdIdade = 0, qtdAltura = 0;
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 33";
            this.Size = new System.Drawing.Size(400, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Idade:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtIdade = new TextBox();
            txtIdade.Location = new System.Drawing.Point(130, 20);
            txtIdade.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Altura (m):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtAltura = new TextBox();
            txtAltura.Location = new System.Drawing.Point(130, 50);
            txtAltura.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 90);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 130);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Enabled = false;
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 180);
            lblRes.Size = new System.Drawing.Size(350, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtIdade);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtAltura);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int idade = int.Parse(txtIdade.Text);
                double altura = double.Parse(txtAltura.Text);

                if (altura < 1.70)
                {
                    somaIdade += idade;
                    qtdIdade++;
                }
                if (idade > 20)
                {
                    somaAltura += altura;
                    qtdAltura++;
                }

                cont++;
                txtIdade.Text = "";
                txtAltura.Text = "";
                if (cont == 45)
                {
                    btnAdd.Enabled = false;
                    btnCalc.Enabled = true;
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string res = "";
            if (qtdIdade > 0)
                resultado += $"Idade média (<1,70m): {somaIdade / qtdIdade:F2}\n";
            if (qtdAltura > 0)
                resultado += $"Altura média (>20 anos): {somaAltura / qtdAltura:F2}";
            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





