﻿using System;
using System.Windows.Forms;

namespace Exercicio35
{
    public partial class Form1 : Form
    {
        private TextBox txtNome, txtSal;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double s = 0;
        private double maior = double.MinValue;
        private double menor = double.MaxValue;
        private int qtd = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 35";
            this.Size = new System.Drawing.Size(400, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Nome:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(130, 20);
            txtNome.Size = new System.Drawing.Size(200, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Salário:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtSal = new TextBox();
            txtSal.Location = new System.Drawing.Point(130, 50);
            txtSal.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 90);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 130);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 180);
            lblRes.Size = new System.Drawing.Size(350, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtNome);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtSal);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double sal = double.Parse(txtSal.Text);
                soma += salario;
                qtd++;
                if (salario > maior) maior = salario;
                if (salario < menor) menor = salario;
                txtNome.Text = "";
                txtSal.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (qtd > 0)
            {
                double med = s / qtd;
                lblRes.Text = $"Res:\nMédia: {med:F2}\nMaior: {maior:F2}\nMenor: {menor:F2}";
            }
            else
            {
                lblRes.Text = "Res: Nenhum salário foi informado";
            }
        }
    }
}






