﻿using System;
using System.Windows.Forms;

namespace Exercicio100
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnAdd, btnMost;
        private Label lblRes;
        private int[] numeros = new int[100];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 100";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Número:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(130, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(290, 20);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnMost = new Button();
            btnMost.Text = "Most";
            btnMost.Location = new System.Drawing.Point(20, 60);
            btnMost.Size = new System.Drawing.Size(100, 30);
            btnMost.Click += btnMost_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 250);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnMost);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                numeros[cont] = int.Parse(txtN.Text);
                cont++;
                txtN.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnMost_Click(object sender, EventArgs e)
        {
            string res = "";
            for (int i = 0; i < cont; i++)
            {
                if (resultado != "") resultado += " ";
                string n = numeros[i].ToString();
                if (numeros[i] % 2 == 0)
                    resultado += $"[VERDE]{num}[/VERDE]";
                else
                    resultado += $"[VERMELHO]{num}[/VERMELHO]";
            }
            lblRes.Text = $"Res: {resultado}\n(Verde = par, Vermelho = ímpar)";
        }
    }
}





