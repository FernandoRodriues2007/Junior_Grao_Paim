﻿using System;
using System.Windows.Forms;

namespace Exercicio22
{
    public partial class Form1 : Form
    {
        private TextBox txtV;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int[] Q = new int[20];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 22";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite valor positivo:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtV = new TextBox();
            txtV.Location = new System.Drawing.Point(180, 20);
            txtV.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 60);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 100);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Enabled = false;
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 150);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtV);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int valor = int.Parse(txtV.Text);
                if (valor > 0)
                {
                    Q[cont] = valor;
                    cont++;
                    txtV.Text = "";
                    if (cont == 20)
                    {
                        btnAdd.Enabled = false;
                        btnCalc.Enabled = true;
                    }
                }
                else
                {
                    lblRes.Text = "Res: Digite apenas números positivos";
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int maior = Q[0];
            int posicao = 0;
            for (int i = 1; i < 20; i++)
            {
                if (Q[i] > maior)
                {
                    maior = Q[i];
                    posicao = i;
                }
            }
            lblRes.Text = $"Res: Maior elemento: {maior}, Posição: {posicao}";
        }
    }
}





