﻿using System;
using System.Windows.Forms;

namespace Exercicio47
{
    public partial class Form1 : Form
    {
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 47";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 20);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 70);
            lblRes.Size = new System.Drawing.Size(350, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            double s = 0;
            double termo = 3;
            while (termo <= 6561)
            {
                soma += termo;
                termo = termo * 3;
            }
            lblRes.Text = $"Res: {soma}";
        }
    }
}





