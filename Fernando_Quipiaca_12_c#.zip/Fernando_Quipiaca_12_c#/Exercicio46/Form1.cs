﻿using System;
using System.Windows.Forms;

namespace Exercicio46
{
    public partial class Form1 : Form
    {
        private TextBox txtUso;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int menos10 = 0;
        private int entre10e15 = 0;
        private int mais15 = 0;
        private int total = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 46";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Uso do restaurante:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtUso = new TextBox();
            txtUso.Location = new System.Drawing.Point(180, 20);
            txtUso.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 60);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 100);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 150);
            lblRes.Size = new System.Drawing.Size(350, 80);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtUso);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int uso = int.Parse(txtUso.Text);
                total++;
                if (uso < 10)
                    menos10++;
                else if (uso >= 10 && uso <= 15)
                    entre10e15++;
                else
                    mais15++;
                txtUso.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (total > 0)
            {
                double perc1 = (menos10 * 100.0) / total;
                double perc2 = (entre10e15 * 100.0) / total;
                double perc3 = (mais15 * 100.0) / total;
                lblRes.Text = $"Res:\n<10: {perc1:F2}%\n10-15: {perc2:F2}%\n>15: {perc3:F2}%";
            }
            else
            {
                lblRes.Text = "Res: Nenhum dado foi informado";
            }
        }
    }
}





