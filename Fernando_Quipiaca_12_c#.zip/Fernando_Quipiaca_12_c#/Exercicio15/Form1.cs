﻿using System;
using System.Windows.Forms;

namespace Exercicio15
{
    public partial class Form1 : Form
    {
        private TextBox txtNome;
        private Button btnAdd, btnOrd;
        private Label lblRes;
        private string[] nomes = new string[100];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 15";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Nome:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(180, 20);
            txtNome.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(390, 20);
            btnAdd.Size = new System.Drawing.Size(80, 30);
            btnAdd.Click += btnAdd_Click;

            btnOrd = new Button();
            btnOrd.Text = "Ord";
            btnOrd.Location = new System.Drawing.Point(20, 60);
            btnOrd.Size = new System.Drawing.Size(100, 30);
            btnOrd.Click += btnOrd_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 150);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtNome);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnOrd);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtNome.Text.Trim() != "")
            {
                nomes[cont] = txtNome.Text;
                cont++;
                txtNome.Text = "";
                txtNome.Focus();
            }
        }

        private void btnOrd_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < cont - 1; i++)
            {
                for (int j = i + 1; j < cont; j++)
                {
                    if (string.Compare(nomes[i], nomes[j], true) > 0)
                    {
                        string t = nomes[i];
                        nomes[i] = nomes[j];
                        nomes[j] = temp;
                    }
                }
            }

            string res = "";
            for (int i = 0; i < cont; i++)
            {
                if (resultado != "") resultado += ", ";
                resultado += nomes[i];
            }

            lblRes.Text = $"Res: {resultado}";
        }
    }
}





