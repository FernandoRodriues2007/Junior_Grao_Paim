﻿using System;
using System.Windows.Forms;

namespace Exercicio84
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnFatorial, btnParImpar, btnPrimo;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 84";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Número:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(130, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnFatorial = new Button();
            btnFatorial.Text = "Fatorial";
            btnFatorial.Location = new System.Drawing.Point(20, 60);
            btnFatorial.Size = new System.Drawing.Size(100, 30);
            btnFatorial.Click += BtnFatorial_Click;

            btnParImpar = new Button();
            btnParImpar.Text = "Par/Ímpar";
            btnParImpar.Location = new System.Drawing.Point(130, 60);
            btnParImpar.Size = new System.Drawing.Size(100, 30);
            btnParImpar.Click += BtnParImpar_Click;

            btnPrimo = new Button();
            btnPrimo.Text = "Primo";
            btnPrimo.Location = new System.Drawing.Point(240, 60);
            btnPrimo.Size = new System.Drawing.Size(100, 30);
            btnPrimo.Click += BtnPrimo_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 150);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnFatorial);
            this.Controls.Add(btnParImpar);
            this.Controls.Add(btnPrimo);
            this.Controls.Add(lblRes);
        }

        private void BtnFatorial_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                long fatorial = 1;
                for (int i = 2; i <= n; i++)
                {
                    fatorial *= i;
                }
                lblRes.Text = $"Res: Fatorial de {n} = {fatorial}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void BtnParImpar_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                string res = n % 2 == 0 ? "Par" : "Ímpar";
                lblRes.Text = $"Res: {n} é {resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void BtnPrimo_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                bool p = true;
                if (n < 2)
                    primo = false;
                else
                {
                    for (int i = 2; i < n; i++)
                    {
                        if (n % i == 0)
                        {
                            primo = false;
                            break;
                        }
                    }
                }
                string res = primo ? "é primo" : "não é primo";
                lblRes.Text = $"Res: {n} {resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }
    }
}





