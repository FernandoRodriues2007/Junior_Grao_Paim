﻿using System;
using System.Windows.Forms;

namespace Exercicio5
{
    public partial class Form1 : Form
    {
        private TextBox txtOp, txtN1, txtN2;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 5";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblOp = new Label();
            lblOp.Text = "Operação (+, -, *, /):";
            lblOp.Location = new System.Drawing.Point(20, 20);
            lblOp.Size = new System.Drawing.Size(150, 20);

            txtOp = new TextBox();
            txtOp.Location = new System.Drawing.Point(180, 20);
            txtOp.Size = new System.Drawing.Size(50, 20);

            Label lbl1 = new Label();
            lbl1.Text = "Número 1:";
            lbl1.Location = new System.Drawing.Point(20, 50);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtN1 = new TextBox();
            txtN1.Location = new System.Drawing.Point(130, 50);
            txtN1.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Número 2:";
            lbl2.Location = new System.Drawing.Point(20, 80);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtN2 = new TextBox();
            txtN2.Location = new System.Drawing.Point(130, 80);
            txtN2.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 120);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 170);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lblOp);
            this.Controls.Add(txtOp);
            this.Controls.Add(lbl1);
            this.Controls.Add(txtN1);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtN2);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                string op = txtOp.Text;
                double n1 = double.Parse(txtN1.Text);
                double n2 = double.Parse(txtN2.Text);
                double res = 0;

                if (op == "+")
                    resultado = num1 + num2;
                else if (op == "-")
                    resultado = num1 - num2;
                else if (op == "*")
                    resultado = num1 * num2;
                else if (op == "/")
                {
                    if (num2 == 0)
                    {
                        lblRes.Text = "Res: Erro - Divisão por zero";
                        return;
                    }
                    resultado = num1 / num2;
                }
                else
                {
                    lblRes.Text = "Res: Operação inválida";
                    return;
                }

                lblRes.Text = $"Res: {resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }
    }
}





