﻿using System;
using System.Windows.Forms;

namespace Exercicio48
{
    public partial class Form1 : Form
    {
        private TextBox txtNome1, txtPeso1, txtAltura1, txtNome2, txtPeso2, txtAltura2;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 48";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Pessoa 1 - Nome:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(120, 20);

            txtNome1 = new TextBox();
            txtNome1.Location = new System.Drawing.Point(150, 20);
            txtNome1.Size = new System.Drawing.Size(200, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Peso:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtPeso1 = new TextBox();
            txtPeso1.Location = new System.Drawing.Point(130, 50);
            txtPeso1.Size = new System.Drawing.Size(100, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Altura:";
            lbl3.Location = new System.Drawing.Point(240, 50);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtAltura1 = new TextBox();
            txtAltura1.Location = new System.Drawing.Point(300, 50);
            txtAltura1.Size = new System.Drawing.Size(100, 20);

            Label lbl4 = new Label();
            lbl4.Text = "Pessoa 2 - Nome:";
            lbl4.Location = new System.Drawing.Point(20, 90);
            lbl4.Size = new System.Drawing.Size(120, 20);

            txtNome2 = new TextBox();
            txtNome2.Location = new System.Drawing.Point(150, 90);
            txtNome2.Size = new System.Drawing.Size(200, 20);

            Label lbl5 = new Label();
            lbl5.Text = "Peso:";
            lbl5.Location = new System.Drawing.Point(20, 120);
            lbl5.Size = new System.Drawing.Size(100, 20);

            txtPeso2 = new TextBox();
            txtPeso2.Location = new System.Drawing.Point(130, 120);
            txtPeso2.Size = new System.Drawing.Size(100, 20);

            Label lbl6 = new Label();
            lbl6.Text = "Altura:";
            lbl6.Location = new System.Drawing.Point(240, 120);
            lbl6.Size = new System.Drawing.Size(100, 20);

            txtAltura2 = new TextBox();
            txtAltura2.Location = new System.Drawing.Point(300, 120);
            txtAltura2.Size = new System.Drawing.Size(100, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 160);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 210);
            lblRes.Size = new System.Drawing.Size(450, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtNome1);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtPeso1);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtAltura1);
            this.Controls.Add(lbl4);
            this.Controls.Add(txtNome2);
            this.Controls.Add(lbl5);
            this.Controls.Add(txtPeso2);
            this.Controls.Add(lbl6);
            this.Controls.Add(txtAltura2);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                double altura1 = double.Parse(txtAltura1.Text);
                double altura2 = double.Parse(txtAltura2.Text);
                double peso1 = double.Parse(txtPeso1.Text);
                double peso2 = double.Parse(txtPeso2.Text);

                string maisAlta = altura1 > altura2 ? txtNome1.Text : txtNome2.Text;
                string maisPesada = peso1 > peso2 ? txtNome1.Text : txtNome2.Text;

                lblRes.Text = $"Res:\nMais alta: {maisAlta}\nMais pesada: {maisPesada}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }
    }
}





