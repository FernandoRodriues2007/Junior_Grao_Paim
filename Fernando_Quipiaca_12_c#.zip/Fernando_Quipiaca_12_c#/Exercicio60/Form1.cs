﻿using System;
using System.Windows.Forms;

namespace Exercicio60
{
    public partial class Form1 : Form
    {
        private TextBox txtMatricula, txtNota1, txtNota2, txtNota3;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int aprovados = 0;
        private int reprovados = 0;
        private int total = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 60";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Matrícula (9999 para encerrar):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(200, 20);

            txtMatricula = new TextBox();
            txtMatricula.Location = new System.Drawing.Point(230, 20);
            txtMatricula.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Nota 1:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtNota1 = new TextBox();
            txtNota1.Location = new System.Drawing.Point(130, 50);
            txtNota1.Size = new System.Drawing.Size(100, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Nota 2:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtNota2 = new TextBox();
            txtNota2.Location = new System.Drawing.Point(130, 80);
            txtNota2.Size = new System.Drawing.Size(100, 20);

            Label lbl4 = new Label();
            lbl4.Text = "Nota 3:";
            lbl4.Location = new System.Drawing.Point(20, 110);
            lbl4.Size = new System.Drawing.Size(100, 20);

            txtNota3 = new TextBox();
            txtNota3.Location = new System.Drawing.Point(130, 110);
            txtNota3.Size = new System.Drawing.Size(100, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 150);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Most Resultados";
            btnCalc.Location = new System.Drawing.Point(20, 190);
            btnCalc.Size = new System.Drawing.Size(150, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 240);
            lblRes.Size = new System.Drawing.Size(450, 140);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtMatricula);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtNota1);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtNota2);
            this.Controls.Add(lbl4);
            this.Controls.Add(txtNota3);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int matricula = int.Parse(txtMatricula.Text);
                if (matricula == 9999)
                {
                    btnCalc_Click(null, null);
                    return;
                }
                double nota1 = double.Parse(txtNota1.Text);
                double nota2 = double.Parse(txtNota2.Text);
                double nota3 = double.Parse(txtNota3.Text);

                double med = (2 * nota1 + 3 * nota2 + 4 * nota3) / 9;
                total++;
                if (media >= 5)
                {
                    aprovados++;
                    lblRes.Text = $"Res: Matrícula: {matricula}, Média: {med:F2}, APROVADO";
                }
                else
                {
                    reprovados++;
                    lblRes.Text = $"Res: Matrícula: {matricula}, Média: {med:F2}, REPROVADO";
                }

                txtMatricula.Text = "";
                txtNota1.Text = "";
                txtNota2.Text = "";
                txtNota3.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            lblRes.Text = $"Res:\nTotal alunos: {total}\nAprovados: {aprovados}\nReprovados: {reprovados}";
        }
    }
}






