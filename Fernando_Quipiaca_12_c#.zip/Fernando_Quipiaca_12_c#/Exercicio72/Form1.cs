﻿using System;
using System.Windows.Forms;

namespace Exercicio72
{
    public partial class Form1 : Form
    {
        private TextBox txtData;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 72";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Data (dd/mm/aaaa):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtData = new TextBox();
            txtData.Location = new System.Drawing.Point(180, 20);
            txtData.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtData);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                string[] partes = txtData.Text.Split('/');
                int dia = int.Parse(partes[0]);
                int mes = int.Parse(partes[1]);
                int ano = int.Parse(partes[2]);
                string[] meses = { "", "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };
                if (mes >= 1 && mes <= 12)
                    lblRes.Text = $"Res: Você nasceu em {dia} de {meses[mes]} de {ano}";
                else
                    lblRes.Text = "Res: Mês inválido";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite data no formato dd/mm/aaaa";
            }
        }
    }
}





