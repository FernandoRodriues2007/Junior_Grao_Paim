﻿using System;
using System.Windows.Forms;

namespace Exercicio38
{
    public partial class Form1 : Form
    {
        private TextBox txtMassa;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 38";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Massa inicial (g):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtMassa = new TextBox();
            txtMassa.Location = new System.Drawing.Point(180, 20);
            txtMassa.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtMassa);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                double massa = double.Parse(txtMassa.Text);
                int tempo = 0;
                while (massa >= 0.05)
                {
                    massa = massa / 2;
                    tempo += 50;
                }
                lblRes.Text = $"Res: Tempo necessário: {tempo} seg";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }
    }
}





