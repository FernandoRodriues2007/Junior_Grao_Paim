﻿using System;
using System.Windows.Forms;

namespace Exercicio78
{
    public partial class Form1 : Form
    {
        private TextBox txtFrase, txtAntiga, txtNova;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 78";
            this.Size = new System.Drawing.Size(500, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Frase:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtFrase = new TextBox();
            txtFrase.Location = new System.Drawing.Point(130, 20);
            txtFrase.Size = new System.Drawing.Size(330, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Palavra antiga:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtAntiga = new TextBox();
            txtAntiga.Location = new System.Drawing.Point(130, 50);
            txtAntiga.Size = new System.Drawing.Size(200, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Palavra nova:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtNova = new TextBox();
            txtNova.Location = new System.Drawing.Point(130, 80);
            txtNova.Size = new System.Drawing.Size(200, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 120);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 170);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtFrase);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtAntiga);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtNova);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private string SubstituirUltima(string frase, string antiga, string nova)
        {
            int ultimaPos = frase.LastIndexOf(antiga);
            if (ultimaPos >= 0)
            {
                string res = frase.Substring(0, ultimaPos) + nova + frase.Substring(ultimaPos + antiga.Length);
                return resultado;
            }
            return frase;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string res = SubstituirUltima(txtFrase.Text, txtAntiga.Text, txtNova.Text);
            lblRes.Text = $"Res: {resultado}";
        }
    }
}





