﻿using System;
using System.Windows.Forms;

namespace Exercicio26
{
    public partial class Form1 : Form
    {
        private TextBox txtCodigo, txtSexo, txth;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double somaSalarioH = 0, somaSalarioM = 0;
        private int qtdH = 0, qtdM = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 26";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Código:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtCodigo = new TextBox();
            txtCodigo.Location = new System.Drawing.Point(130, 20);
            txtCodigo.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Sexo (M/F):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtSexo = new TextBox();
            txtSexo.Location = new System.Drawing.Point(130, 50);
            txtSexo.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "h/Aula:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txth = new TextBox();
            txth.Location = new System.Drawing.Point(130, 80);
            txth.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 120);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc Médias";
            btnCalc.Location = new System.Drawing.Point(20, 160);
            btnCalc.Size = new System.Drawing.Size(150, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 210);
            lblRes.Size = new System.Drawing.Size(450, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtCodigo);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtSexo);
            this.Controls.Add(lbl3);
            this.Controls.Add(txth);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int codigo = int.Parse(txtCodigo.Text);
                string sexo = txtSexo.Text.ToUpper();
                double h = double.Parse(txth.Text);
                double salarioBruto = h * 50;
                double salarioLiquido = 0;

                if (sexo == "M")
                {
                    salarioLiquido = salarioBruto * 0.9;
                    somaSalarioH += salarioLiquido;
                    qtdH++;
                }
                else if (sexo == "F")
                {
                    salarioLiquido = salarioBruto * 0.95;
                    somaSalarioM += salarioLiquido;
                    qtdM++;
                }

                txtCodigo.Text = "";
                txtSexo.Text = "";
                txth.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string res = "";
            if (qtdH > 0)
                resultado += $"Média salário homens: {somaSalarioH / qtdH:F2}\n";
            if (qtdM > 0)
                resultado += $"Média salário mulheres: {somaSalarioM / qtdM:F2}";
            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





