﻿using System;
using System.Windows.Forms;

namespace Exercicio54
{
    public partial class Form1 : Form
    {
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 54";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 20);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 70);
            lblRes.Size = new System.Drawing.Size(350, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            double chico = 1.50;
            double ze = 1.10;
            int a = 0;
            while (ze <= chico)
            {
                chico += 0.02;
                ze += 0.03;
                anos++;
            }
            lblRes.Text = $"Res: {anos} anos";
        }
    }
}





