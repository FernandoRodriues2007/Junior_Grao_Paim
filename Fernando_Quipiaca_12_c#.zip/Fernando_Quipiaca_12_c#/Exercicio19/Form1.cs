﻿using System;
using System.Windows.Forms;

namespace Exercicio19
{
    public partial class Form1 : Form
    {
        private TextBox txtStr;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 19";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Texto:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtStr = new TextBox();
            txtStr.Location = new System.Drawing.Point(130, 20);
            txtStr.Size = new System.Drawing.Size(300, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 250);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtStr);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string s = txtStr.Text;
            string res = "";

            resultado += $"a) Número de caracteres: {str.Length}\n";
            resultado += $"b) String em maiúsculo: {str.ToUpper()}\n";

            int vog = 0;
            string vogaisStr = "aeiouAEIOU";
            for (int i = 0; i < str.Length; i++)
            {
                if (vogaisStr.Contains(str[i]))
                    vogais++;
            }
            resultado += $"c) Número de vogais: {vogais}\n";

            resultado += $"d) Começa com 'UNI': {str.StartsWith("UNI")}\n";
            resultado += $"e) Termina com 'RIO': {str.EndsWith("RIO")}\n";

            int dig = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (char.IsDigit(str[i]))
                    digitos++;
            }
            resultado += $"f) Número de dígitos: {digitos}\n";

            string sLimpa = str.Replace(" ", "").ToLower();
            bool pal = true;
            for (int i = 0; i < strLimpa.Length / 2; i++)
            {
                if (strLimpa[i] != strLimpa[strLimpa.Length - 1 - i])
                {
                    palindromo = false;
                    break;
                }
            }
            resultado += $"g) É palíndromo: {palindromo}";

            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





