﻿using System;
using System.Windows.Forms;

namespace Exercicio58
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 58";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "N (>= 2):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(130, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 150);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                if (n < 2)
                {
                    lblRes.Text = "Res: N deve ser >= 2";
                    return;
                }
                long a = 0, b = 1;
                string res = "0, 1";
                for (int i = 2; i < n; i++)
                {
                    long c = a + b;
                    resultado += ", " + c;
                    a = b;
                    b = c;
                }
                lblRes.Text = $"Res: {resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }
    }
}





