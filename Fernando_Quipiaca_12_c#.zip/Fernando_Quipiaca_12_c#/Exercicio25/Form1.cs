﻿using System;
using System.Windows.Forms;

namespace Exercicio25
{
    public partial class Form1 : Form
    {
        private TextBox txtV;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double s = 0;
        private int qtd = 0;
        private int pos = 0;
        private int neg = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 25";
            this.Size = new System.Drawing.Size(400, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite um valor:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtV = new TextBox();
            txtV.Location = new System.Drawing.Point(180, 20);
            txtV.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 60);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 100);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 150);
            lblRes.Size = new System.Drawing.Size(350, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtV);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double v = double.Parse(txtV.Text);
                s += v;
                qtd++;
                if (valor > 0) positivos++;
                else if (v < 0) negativos++;
                txtV.Text = "";
                txtV.Focus();
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (qtd > 0)
            {
                double med = s / qtd;
                double percPos = (positivos * 100.0) / qtd;
                double percNeg = (negativos * 100.0) / qtd;
                lblRes.Text = $"Res:\nMédia: {med:F2}\nPositivos: {positivos} ({percPos:F2}%)\nNegativos: {negativos} ({percNeg:F2}%)";
            }
            else
            {
                lblRes.Text = "Res: Nenhum valor foi digitado";
            }
        }
    }
}






