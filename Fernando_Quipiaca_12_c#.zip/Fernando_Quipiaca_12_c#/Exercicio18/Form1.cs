﻿using System;
using System.Windows.Forms;

namespace Exercicio18
{
    public partial class Form1 : Form
    {
        private TextBox txtN, txtIni, txtFim;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 18";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Número:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(130, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Início:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtIni = new TextBox();
            txtIni.Location = new System.Drawing.Point(130, 50);
            txtIni.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Fim:";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtFim = new TextBox();
            txtFim.Location = new System.Drawing.Point(130, 80);
            txtFim.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 120);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 170);
            lblRes.Size = new System.Drawing.Size(450, 200);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtN);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtIni);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtFim);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                int ini = int.Parse(txtIni.Text);
                int fim = int.Parse(txtFim.Text);
                string res = "";

                for (int i = inicio; i <= fim; i++)
                {
                    if (resultado != "") resultado += "\n";
                    resultado += $"{num} x {i} = {num * i}";
                }

                lblRes.Text = $"Res:\n{resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite números válidos";
            }
        }
    }
}





