﻿using System;
using System.Windows.Forms;

namespace Exercicio86
{
    public partial class Form1 : Form
    {
        private TextBox txtNome;
        private Button btnAdd, btnCalc;
        private ListBox listBox;
        private Label lblRes;
        private int[] contes = new int[100];
        private string[] nomes = new string[100];
        private int totalNomes = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 86";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Nome:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(130, 20);
            txtNome.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(340, 20);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            listBox = new ListBox();
            listBox.Location = new System.Drawing.Point(20, 60);
            listBox.Size = new System.Drawing.Size(420, 150);

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 220);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 270);
            lblRes.Size = new System.Drawing.Size(450, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtNome);
            this.Controls.Add(btnAdd);
            this.Controls.Add(listBox);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string n = txtNome.Text;
            if (nome.Length > 0)
            {
                int indice = -1;
                for (int i = 0; i < totalNomes; i++)
                {
                    if (nomes[i] == nome)
                    {
                        indice = i;
                        break;
                    }
                }
                if (indice >= 0)
                {
                    contes[indice]++;
                    listBox.Items[indice] = $"{nome} ({contes[indice]})";
                }
                else
                {
                    nomes[totalNomes] = nome;
                    contes[totalNomes] = 1;
                    listBox.Items.Add($"{nome} (1)");
                    totalNomes++;
                }
                txtNome.Text = "";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (totalNomes == 0)
            {
                lblRes.Text = "Res: Nenhum nome foi inserido";
                return;
            }
            int maiorIndice = 0;
            int menorIndice = 0;
            int maiorConsecutivo = 0;
            for (int i = 0; i < totalNomes; i++)
            {
                if (contes[i] > contes[maiorIndice])
                    maiorIndice = i;
                if (contes[i] < contes[menorIndice])
                    menorIndice = i;
                if (contes[i] > maiorConsecutivo)
                    maiorConsecutivo = contes[i];
            }
            lblRes.Text = $"Res:\nMais inserido: {nomes[maiorIndice]} ({contes[maiorIndice]} vezes)\nMenos inserido: {nomes[menorIndice]}\nMaior consecutivo: {maiorConsecutivo}";
        }
    }
}





