﻿using System;
using System.Windows.Forms;

namespace Exercicio10
{
    public partial class Form1 : Form
    {
        private TextBox txtV;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double s = 0;
        private int qtd = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 10";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Valor:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(200, 20);

            txtV = new TextBox();
            txtV.Location = new System.Drawing.Point(20, 50);
            txtV.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(180, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 90);
            btnCalc.Size = new System.Drawing.Size(150, 30);
            btnCalc.Enabled = false;
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(350, 80);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtV);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double v = double.Parse(txtV.Text);
                if (v < 0)
                {
                    btnCalc.Enabled = true;
                    btnCalc_Click(null, null);
                    return;
                }
                s += v;
                qtd++;
                txtV.Text = "";
                txtV.Focus();
            }
            catch
            {
                lblRes.Text = "Res: Erro";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (qtd > 0)
            {
                double med = s / qtd;
                lblRes.Text = $"Res: {med:F2}";
            }
            else
            {
                lblRes.Text = "Res: Sem valores";
            }
            s = 0;
            qtd = 0;
            btnCalc.Enabled = false;
        }
    }
}





