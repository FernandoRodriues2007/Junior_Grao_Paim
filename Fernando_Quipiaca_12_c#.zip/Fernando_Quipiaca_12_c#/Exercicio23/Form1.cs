﻿using System;
using System.Windows.Forms;

namespace Exercicio23
{
    public partial class Form1 : Form
    {
        private TextBox txtTamanho;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 23";
            this.Size = new System.Drawing.Size(500, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Tamanho da base (5-15):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtTamanho = new TextBox();
            txtTamanho.Location = new System.Drawing.Point(180, 20);
            txtTamanho.Size = new System.Drawing.Size(100, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 350);
            lblRes.AutoSize = false;
            lblRes.Font = new System.Drawing.Font("Courier New", 10);

            this.Controls.Add(lbl);
            this.Controls.Add(txtTamanho);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int tamanho = int.Parse(txtTamanho.Text);
                if (tamanho < 5 || tamanho > 15)
                {
                    lblRes.Text = "Res: Tamanho deve estar entre 5 e 15";
                    return;
                }

                string res = "";
                for (int i = 1; i <= tamanho; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        resultado += "#";
                    }
                    resultado += "\n";
                }

                lblRes.Text = $"Res:\n{resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }
    }
}





