﻿using System;
using System.Windows.Forms;

namespace Exercicio14
{
    public partial class Form1 : Form
    {
        private TextBox txtP1, txtP2;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 14";
            this.Size = new System.Drawing.Size(500, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "P1:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtP1 = new TextBox();
            txtP1.Location = new System.Drawing.Point(130, 20);
            txtP1.Size = new System.Drawing.Size(300, 20);

            Label lbl2 = new Label();
            lbl2.Text = "P2:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtP2 = new TextBox();
            txtP2.Location = new System.Drawing.Point(130, 50);
            txtP2.Size = new System.Drawing.Size(300, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 80);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtP1);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtP2);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string p1 = txtP1.Text;
            string p2 = txtP2.Text;
            string res = "";

            if (p1 == p2)
            {
                resultado += "a) As palavras são iguais\n";
            }
            else
            {
                resultado += "a) As palavras são diferentes\n";
                if (p1.Length > p2.Length)
                    resultado += $"b) Palavra 1 tem maior comprimento ({p1.Length} > {p2.Length})\n";
                else if (p2.Length > p1.Length)
                    resultado += $"b) Palavra 2 tem maior comprimento ({p2.Length} > {p1.Length})\n";
                else
                    resultado += $"b) As palavras têm o mesmo comprimento ({p1.Length})\n";

                if (p1.Contains(p2))
                    resultado += "c) Palavra 2 é substring da Palavra 1";
                else
                    resultado += "c) Palavra 2 NÃO é substring da Palavra 1";
            }

            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





