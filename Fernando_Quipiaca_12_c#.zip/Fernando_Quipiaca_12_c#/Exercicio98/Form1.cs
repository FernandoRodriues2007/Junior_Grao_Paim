﻿using System;
using System.Windows.Forms;

namespace Exercicio98
{
    public partial class Form1 : Form
    {
        private TextBox txtTexto;
        private Button btnOk;
        private RichTextBox rtbResultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 98";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Texto (use /* */ para comentários):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(250, 20);

            txtTexto = new TextBox();
            txtTexto.Location = new System.Drawing.Point(20, 50);
            txtTexto.Size = new System.Drawing.Size(440, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            rtbResultado = new RichTextBox();
            rtbResultado.Location = new System.Drawing.Point(20, 140);
            rtbResultado.Size = new System.Drawing.Size(440, 120);

            this.Controls.Add(lbl);
            this.Controls.Add(txtTexto);
            this.Controls.Add(btnOk);
            this.Controls.Add(rtbResultado);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            rtbResultado.Clear();
            int ini = 0;
            while (true)
            {
                int posInicio = texto.IndexOf("/*", inicio);
                if (posInicio < 0)
                {
                    rtbResultado.SelectionStart = rtbResultado.TextLength;
                    rtbResultado.SelectionLength = 0;
                    rtbResultado.SelectionColor = System.Drawing.Color.Black;
                    rtbResultado.AppendText(texto.Substring(inicio));
                    break;
                }
                rtbResultado.SelectionStart = rtbResultado.TextLength;
                rtbResultado.SelectionLength = 0;
                rtbResultado.SelectionColor = System.Drawing.Color.Black;
                rtbResultado.AppendText(texto.Substring(inicio, posInicio - inicio));

                int posFim = texto.IndexOf("*/", posInicio);
                if (posFim < 0)
                {
                    rtbResultado.AppendText(texto.Substring(posInicio));
                    break;
                }

                rtbResultado.SelectionStart = rtbResultado.TextLength;
                rtbResultado.SelectionLength = 0;
                rtbResultado.SelectionColor = System.Drawing.Color.Red;
                rtbResultado.AppendText(texto.Substring(posInicio, posFim + 2 - posInicio));

                inicio = posFim + 2;
            }
        }
    }
}





