﻿using System;
using System.Windows.Forms;

namespace Exercicio11
{
    public partial class Form1 : Form
    {
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 11";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 20);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 70);
            lblRes.Size = new System.Drawing.Size(450, 300);
            lblRes.AutoSize = false;

            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private int SomaDivisores(int n)
        {
            int s = 0;
            for (int i = 1; i < n; i++)
            {
                if (n % i == 0)
                    soma += i;
            }
            return soma;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string res = "";
            for (int i = 1; i <= 100000; i++)
            {
                int s1 = SomaDivisores(i);
                if (soma1 > i && soma1 <= 100000)
                {
                    int s2 = SomaDivisores(soma1);
                    if (soma2 == i)
                    {
                        if (resultado != "") resultado += "\n";
                        resultado += $"({i}, {soma1})";
                    }
                }
            }
            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





