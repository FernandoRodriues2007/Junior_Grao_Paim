﻿using System;
using System.Windows.Forms;

namespace Exercicio12
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnAdd, btnVer;
        private Label lblRes;
        private int[] array = new int[10];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 12";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite 10 números:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(200, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(20, 50);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(180, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            Label lbl2 = new Label();
            lbl2.Text = "Número para comparar:";
            lbl2.Location = new System.Drawing.Point(20, 90);
            lbl2.Size = new System.Drawing.Size(150, 20);

            btnVer = new Button();
            btnVer.Text = "Ver";
            btnVer.Location = new System.Drawing.Point(20, 120);
            btnVer.Size = new System.Drawing.Size(100, 30);
            btnVer.Enabled = false;
            btnVer.Click += btnVer_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 160);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnAdd);
            this.Controls.Add(lbl2);
            this.Controls.Add(btnVer);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (cont < 10)
                {
                    array[cont] = int.Parse(txtN.Text);
                    cont++;
                    txtN.Text = "";
                    if (cont == 10)
                    {
                        btnAdd.Enabled = false;
                        btnVer.Enabled = true;
                        lblRes.Text = "Res: 10 números adicionados. Digite um número para comparar.";
                    }
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                int c = 0;
                for (int i = 0; i < 10; i++)
                {
                    if (array[i] < num)
                        count++;
                }
                lblRes.Text = $"Res: {count} números são inferiores a {num}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }
    }
}





