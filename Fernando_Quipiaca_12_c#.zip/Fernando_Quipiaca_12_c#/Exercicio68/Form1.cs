﻿using System;
using System.Windows.Forms;

namespace Exercicio68
{
    public partial class Form1 : Form
    {
        private TextBox txtFrase, txtPalavra;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 68";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Frase:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtFrase = new TextBox();
            txtFrase.Location = new System.Drawing.Point(130, 20);
            txtFrase.Size = new System.Drawing.Size(330, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Palavra:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtPalavra = new TextBox();
            txtPalavra.Location = new System.Drawing.Point(130, 50);
            txtPalavra.Size = new System.Drawing.Size(330, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtFrase);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtPalavra);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            string palavra = txtPalavra.Text;
            int indice = frase.IndexOf(palavra);
            if (indice >= 0)
                lblRes.Text = $"Res: Índice: {indice}";
            else
                lblRes.Text = "Res: Palavra não encontrada";
        }
    }
}





