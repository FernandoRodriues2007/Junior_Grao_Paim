﻿using System;
using System.Windows.Forms;

namespace Exercicio85
{
    public partial class Form1 : Form
    {
        private TextBox txtEntrada;
        private ComboBox cmbTipo;
        private Button btnOk;
        private Label lblRes;
        private string[] lista = { "10", "20", "30", "40", "50" };

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 85";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Tipo de validação:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(150, 20);

            cmbTipo = new ComboBox();
            cmbTipo.Location = new System.Drawing.Point(180, 20);
            cmbTipo.Size = new System.Drawing.Size(250, 20);
            cmbTipo.Items.AddRange(new string[] { "Apenas números", "Apenas texto", "Apenas pares", "Apenas vogais", "Apenas primos", "Valores da lista" });
            cmbTipo.SelectedIndex = 0;
            cmbTipo.SelectedIndexChanged += CmbTipo_SelectedIndexChanged;

            Label lbl2 = new Label();
            lbl2.Text = "Entrada:";
            lbl2.Location = new System.Drawing.Point(20, 60);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtEntrada = new TextBox();
            txtEntrada.Location = new System.Drawing.Point(130, 60);
            txtEntrada.Size = new System.Drawing.Size(300, 20);
            txtEntrada.KeyPress += TxtEntrada_KeyPress;

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 100);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 150);
            lblRes.Size = new System.Drawing.Size(450, 120);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(cmbTipo);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtEntrada);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void CmbTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEntrada.Text = "";
        }

        private void TxtEntrada_KeyPress(object sender, KeyPressEventArgs e)
        {
            int tipo = cmbTipo.SelectedIndex;
            if (tipo == 0)
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            }
            else if (tipo == 1)
            {
                if (char.IsDigit(e.KeyChar))
                    e.Handled = true;
            }
            else if (tipo == 2)
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            }
            else if (tipo == 3)
            {
                string vogais = "aeiouAEIOU";
                if (!vogais.Contains(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            }
            else if (tipo == 4)
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            }
            else if (tipo == 5)
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                    e.Handled = true;
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            int tipo = cmbTipo.SelectedIndex;
            string entrada = txtEntrada.Text;
            bool valido = false;

            if (tipo == 0)
            {
                valido = entrada.Length > 0 && int.TryParse(entrada, out _);
            }
            else if (tipo == 1)
            {
                valido = entrada.Length > 0 && !int.TryParse(entrada, out _);
            }
            else if (tipo == 2)
            {
                if (int.TryParse(entrada, out int num))
                    valido = num % 2 == 0;
            }
            else if (tipo == 3)
            {
                string vogais = "aeiouAEIOU";
                valido = true;
                for (int i = 0; i < entrada.Length; i++)
                {
                    if (!vogais.Contains(entrada[i]))
                    {
                        valido = false;
                        break;
                    }
                }
            }
            else if (tipo == 4)
            {
                if (int.TryParse(entrada, out int num))
                {
                    bool p = true;
                    if (num < 2)
                        primo = false;
                    else
                    {
                        for (int i = 2; i < num; i++)
                        {
                            if (num % i == 0)
                            {
                                primo = false;
                                break;
                            }
                        }
                    }
                    valido = primo;
                }
            }
            else if (tipo == 5)
            {
                valido = false;
                for (int i = 0; i < lista.Length; i++)
                {
                    if (entrada == lista[i])
                    {
                        valido = true;
                        break;
                    }
                }
            }

            lblRes.Text = $"Res: Entrada válida: {valido}";
        }
    }
}





