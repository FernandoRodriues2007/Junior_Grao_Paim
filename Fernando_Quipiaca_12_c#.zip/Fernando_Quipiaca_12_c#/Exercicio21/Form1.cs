﻿using System;
using System.Windows.Forms;

namespace Exercicio21
{
    public partial class Form1 : Form
    {
        private TextBox txtNome;
        private Button btnAdd, btnBuscar;
        private Label lblRes;
        private string[] nomes = new string[10];
        private int cont = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 21";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite 10 nomes:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(150, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(20, 50);
            txtNome.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(230, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            Label lbl2 = new Label();
            lbl2.Text = "Nome para buscar:";
            lbl2.Location = new System.Drawing.Point(20, 90);
            lbl2.Size = new System.Drawing.Size(150, 20);

            btnBuscar = new Button();
            btnBuscar.Text = "Buscar";
            btnBuscar.Location = new System.Drawing.Point(20, 120);
            btnBuscar.Size = new System.Drawing.Size(100, 30);
            btnBuscar.Enabled = false;
            btnBuscar.Click += BtnBuscar_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 160);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtNome);
            this.Controls.Add(btnAdd);
            this.Controls.Add(lbl2);
            this.Controls.Add(btnBuscar);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cont < 10)
            {
                nomes[cont] = txtNome.Text;
                cont++;
                txtNome.Text = "";
                if (cont == 10)
                {
                    btnAdd.Enabled = false;
                    btnBuscar.Enabled = true;
                    lblRes.Text = "Res: 10 nomes adicionados. Digite um nome para buscar.";
                }
            }
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            string nomeBusca = txtNome.Text;
            bool achou = false;
            for (int i = 0; i < 10; i++)
            {
                if (nomes[i] == nomeBusca)
                {
                    achou = true;
                    break;
                }
            }
            lblRes.Text = achou ? "Res: ACHEI" : "Res: NÃO ACHEI";
        }
    }
}





