﻿using System;
using System.Windows.Forms;

namespace Exercicio42
{
    public partial class Form1 : Form
    {
        private TextBox txtN;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double maior = double.MinValue;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 42";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Digite número (até 9999):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(200, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(20, 50);
            txtN.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(180, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Most Maior";
            btnCalc.Location = new System.Drawing.Point(20, 90);
            btnCalc.Size = new System.Drawing.Size(150, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtN);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                double num = double.Parse(txtN.Text);
                if (num <= 9999)
                {
                    if (num > maior) maior = num;
                    txtN.Text = "";
                }
                else
                {
                    lblRes.Text = "Res: Número deve ser <= 9999";
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite um número válido";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (maior != double.MinValue)
                lblRes.Text = $"Res: Maior número: {maior}";
            else
                lblRes.Text = "Res: Nenhum número foi digitado";
        }
    }
}





