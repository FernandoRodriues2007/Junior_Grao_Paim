﻿using System;
using System.Windows.Forms;

namespace Exercicio77
{
    public partial class Form1 : Form
    {
        private TextBox txtPalavra;
        private Button btnAdd;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 77";
            this.Size = new System.Drawing.Size(500, 300);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Palavra (começa com 'f' para encerrar):";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(250, 20);

            txtPalavra = new TextBox();
            txtPalavra.Location = new System.Drawing.Point(20, 50);
            txtPalavra.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(230, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 100);
            lblRes.Size = new System.Drawing.Size(450, 180);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtPalavra);
            this.Controls.Add(btnAdd);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string palavra = txtPalavra.Text;
            if (palavra.Length > 0)
            {
                char primeira = palavra[0];
                char ultima = palavra[palavra.Length - 1];
                string res = lblRes.Text;
                if (resultado == "Res:")
                    resultado = "";
                else
                    resultado += "\n";
                resultado += $"{palavra} → {primeira} - {ultima}";
                lblRes.Text = "Res: " + resultado.Replace("Res: ", "");
                if (palavra[0] == 'f' || palavra[0] == 'F')
                {
                    btnAdd.Enabled = false;
                }
                else
                {
                    txtPalavra.Text = "";
                }
            }
        }
    }
}





