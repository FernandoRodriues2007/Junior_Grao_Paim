﻿using System;
using System.Windows.Forms;

namespace Exercicio99
{
    public partial class Form1 : Form
    {
        private TextBox txtNs;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 99";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "15 números separados por vírgula:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(250, 20);

            txtNs = new TextBox();
            txtNs.Location = new System.Drawing.Point(20, 50);
            txtNs.Size = new System.Drawing.Size(440, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtNs);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                string[] partes = txtNs.Text.Split(',');
                double s = 0;
                for (int i = 0; i < partes.Length; i++)
                {
                    soma += double.Parse(partes[i].Trim());
                }
                lblRes.Text = $"Res: Soma = {soma}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite 15 números separados por vírgula";
            }
        }
    }
}





