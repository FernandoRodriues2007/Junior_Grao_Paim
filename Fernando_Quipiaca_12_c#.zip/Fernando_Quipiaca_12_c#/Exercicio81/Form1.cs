﻿using System;
using System.Windows.Forms;

namespace Exercicio81
{
    public partial class Form1 : Form
    {
        private TextBox txtStr1, txtStr2;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 81";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "String 1:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtStr1 = new TextBox();
            txtStr1.Location = new System.Drawing.Point(130, 20);
            txtStr1.Size = new System.Drawing.Size(330, 20);

            Label lbl2 = new Label();
            lbl2.Text = "String 2:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtStr2 = new TextBox();
            txtStr2.Location = new System.Drawing.Point(130, 50);
            txtStr2.Size = new System.Drawing.Size(330, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtStr1);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtStr2);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string s1 = txtStr1.Text.ToLower();
            string s2 = txtStr2.Text.ToLower();
            string s1Reverso = "";
            for (int i = s1.Length - 1; i >= 0; i--)
            {
                s1Reverso += s1[i];
            }
            bool saoPalindromas = (s1Reverso == s2);
            lblRes.Text = $"Res: São palíndromas mútuas: {saoPalindromas}";
        }
    }
}





