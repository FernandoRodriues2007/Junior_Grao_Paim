﻿using System;
using System.Windows.Forms;

namespace Exercicio71
{
    public partial class Form1 : Form
    {
        private TextBox txtNome;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 71";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Nome:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(130, 20);
            txtNome.Size = new System.Drawing.Size(330, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtNome);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string n = txtNome.Text;
            string res = "";
            for (int i = nome.Length - 1; i >= 0; i--)
            {
                resultado += char.ToUpper(nome[i]);
            }
            lblRes.Text = $"Res: {resultado}";
        }
    }
}





