﻿using System;
using System.Windows.Forms;

namespace Exercicio96
{
    public partial class Form1 : Form
    {
        private TextBox txtN, txtV;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int[] valores = new int[100];
        private int cont = 0;
        private int n = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 96";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "N (qtd):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(150, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(180, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Valor:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtV = new TextBox();
            txtV.Location = new System.Drawing.Point(130, 50);
            txtV.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(290, 50);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 90);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Enabled = false;
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 230);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtN);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtV);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (n == 0)
                {
                    n = int.Parse(txtN.Text);
                }
                valores[cont] = int.Parse(txtV.Text);
                cont++;
                txtV.Text = "";
                if (cont == n)
                {
                    btnAdd.Enabled = false;
                    btnCalc.Enabled = true;
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string res = "";
            for (int i = 0; i < n; i++)
            {
                long fatorial = 1;
                for (int j = 2; j <= valores[i]; j++)
                {
                    fatorial *= j;
                }
                if (resultado != "") resultado += "\n";
                resultado += $"Valor: {valores[i]}, Fatorial: {fatorial}";
            }
            lblRes.Text = $"Res:\n{resultado}";
        }
    }
}





