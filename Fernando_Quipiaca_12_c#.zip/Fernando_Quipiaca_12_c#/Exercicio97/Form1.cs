﻿using System;
using System.Windows.Forms;

namespace Exercicio97
{
    public partial class Form1 : Form
    {
        private Button btnIni, btnParar;
        private Label lblRes;
        private Timer timer;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 97";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnIni = new Button();
            btnIni.Text = "Iniciar";
            btnIni.Location = new System.Drawing.Point(20, 20);
            btnIni.Size = new System.Drawing.Size(100, 30);
            btnIni.Click += btnIni_Click;

            btnParar = new Button();
            btnParar.Text = "Parar";
            btnParar.Location = new System.Drawing.Point(130, 20);
            btnParar.Size = new System.Drawing.Size(100, 30);
            btnParar.Enabled = false;
            btnParar.Click += BtnParar_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 70);
            lblRes.Size = new System.Drawing.Size(350, 100);
            lblRes.AutoSize = false;
            lblRes.Font = new System.Drawing.Font("Arial", 12, System.Drawing.FontStyle.Bold);

            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;

            this.Controls.Add(btnIni);
            this.Controls.Add(btnParar);
            this.Controls.Add(lblRes);
        }

        private void btnIni_Click(object sender, EventArgs e)
        {
            timer.Start();
            btnIni.Enabled = false;
            btnParar.Enabled = true;
        }

        private void BtnParar_Click(object sender, EventArgs e)
        {
            timer.Stop();
            btnIni.Enabled = true;
            btnParar.Enabled = false;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblRes.Text = "Res: " + DateTime.Now.ToString("HH:mm:ss");
        }
    }
}





