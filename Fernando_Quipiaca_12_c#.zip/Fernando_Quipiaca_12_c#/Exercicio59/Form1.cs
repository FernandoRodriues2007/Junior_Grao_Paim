﻿using System;
using System.Windows.Forms;

namespace Exercicio59
{
    public partial class Form1 : Form
    {
        private TextBox txtIdade, txtSexo, txtOlhos, txtCabelos;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private int maiorIdade = int.MinValue;
        private int mulheresIdade = 0;
        private int olhosVerdesCabelosLouros = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 59";
            this.Size = new System.Drawing.Size(500, 350);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Idade (-1 para encerrar):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(200, 20);

            txtIdade = new TextBox();
            txtIdade.Location = new System.Drawing.Point(230, 20);
            txtIdade.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Sexo (M/F):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtSexo = new TextBox();
            txtSexo.Location = new System.Drawing.Point(130, 50);
            txtSexo.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "Olhos (azuis/verdes/castanhos):";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(200, 20);

            txtOlhos = new TextBox();
            txtOlhos.Location = new System.Drawing.Point(230, 80);
            txtOlhos.Size = new System.Drawing.Size(150, 20);

            Label lbl4 = new Label();
            lbl4.Text = "Cabelos (louros/castanhos/pretos):";
            lbl4.Location = new System.Drawing.Point(20, 110);
            lbl4.Size = new System.Drawing.Size(200, 20);

            txtCabelos = new TextBox();
            txtCabelos.Location = new System.Drawing.Point(230, 110);
            txtCabelos.Size = new System.Drawing.Size(150, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 150);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Calc";
            btnCalc.Location = new System.Drawing.Point(20, 190);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 240);
            lblRes.Size = new System.Drawing.Size(450, 100);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtIdade);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtSexo);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtOlhos);
            this.Controls.Add(lbl4);
            this.Controls.Add(txtCabelos);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int idade = int.Parse(txtIdade.Text);
                if (idade == -1)
                {
                    btnCalc_Click(null, null);
                    return;
                }
                string sexo = txtSexo.Text.ToUpper();
                string olhos = txtOlhos.Text.ToLower();
                string cabelos = txtCabelos.Text.ToLower();

                if (idade > maiorIdade) maiorIdade = idade;
                if (sexo == "F" && idade >= 18 && idade <= 35)
                    mulheresIdade++;
                if (olhos == "verdes" && cabelos == "louros")
                    olhosVerdesCabelosLouros++;

                txtIdade.Text = "";
                txtSexo.Text = "";
                txtOlhos.Text = "";
                txtCabelos.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            lblRes.Text = $"Res:\na) Maior idade: {maiorIdade}\nb) Mulheres 18-35: {mulheresIdade}\nc) Olhos verdes e cabelos louros: {olhosVerdesCabelosLouros}";
        }
    }
}





