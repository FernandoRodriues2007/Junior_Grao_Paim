﻿using System;
using System.Windows.Forms;

namespace Exercicio64
{
    public partial class Form1 : Form
    {
        private TextBox txtNome, txtDiarias;
        private Button btnAdd, btnCalc;
        private Label lblRes;
        private double totalHotel = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 64";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Nome do cliente:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(150, 20);

            txtNome = new TextBox();
            txtNome.Location = new System.Drawing.Point(180, 20);
            txtNome.Size = new System.Drawing.Size(200, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Número de diárias:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(150, 20);

            txtDiarias = new TextBox();
            txtDiarias.Location = new System.Drawing.Point(180, 50);
            txtDiarias.Size = new System.Drawing.Size(200, 20);

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new System.Drawing.Point(20, 90);
            btnAdd.Size = new System.Drawing.Size(100, 30);
            btnAdd.Click += btnAdd_Click;

            btnCalc = new Button();
            btnCalc.Text = "Total Hotel";
            btnCalc.Location = new System.Drawing.Point(20, 130);
            btnCalc.Size = new System.Drawing.Size(100, 30);
            btnCalc.Click += btnCalc_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 180);
            lblRes.Size = new System.Drawing.Size(450, 200);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtNome);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtDiarias);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnCalc);
            this.Controls.Add(lblRes);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string n = txtNome.Text;
                int diarias = int.Parse(txtDiarias.Text);
                double taxa = 0;
                if (diarias < 15)
                    taxa = 4.0;
                else if (diarias == 15)
                    taxa = 3.6;
                else
                    taxa = 3.0;

                double total = (50.0 + taxa) * diarias;
                totalHotel += total;
                lblRes.Text = $"Res: {nome}: R$ {total:F2}\n" + lblRes.Text.Replace("Res: ", "");

                txtNome.Text = "";
                txtDiarias.Text = "";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            lblRes.Text = $"Res: Total ganho pelo hotel: R$ {totalHotel:F2}";
        }
    }
}





