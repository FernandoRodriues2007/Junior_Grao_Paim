﻿using System;
using System.Windows.Forms;

namespace Exercicio82
{
    public partial class Form1 : Form
    {
        private TextBox txtTipo, txtTamanho;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 82";
            this.Size = new System.Drawing.Size(500, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Tipo (losango/triangulo):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(200, 20);

            txtTipo = new TextBox();
            txtTipo.Location = new System.Drawing.Point(230, 20);
            txtTipo.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Tamanho (linhas):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(150, 20);

            txtTamanho = new TextBox();
            txtTamanho.Location = new System.Drawing.Point(180, 50);
            txtTamanho.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(450, 330);
            lblRes.AutoSize = false;
            lblRes.Font = new System.Drawing.Font("Courier New", 10);

            this.Controls.Add(lbl1);
            this.Controls.Add(txtTipo);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtTamanho);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                string tipo = txtTipo.Text.ToLower();
                int tamanho = int.Parse(txtTamanho.Text);
                string res = "";

                if (tipo == "triangulo")
                {
                    for (int i = 1; i <= tamanho; i++)
                    {
                        for (int j = 1; j <= i; j++)
                        {
                            resultado += "%";
                        }
                        resultado += "\n";
                    }
                }
                else if (tipo == "losango")
                {
                    for (int i = 1; i <= tamanho; i++)
                    {
                        for (int j = 1; j <= tamanho - i; j++)
                            resultado += " ";
                        for (int j = 1; j <= 2 * i - 1; j++)
                            resultado += "%";
                        resultado += "\n";
                    }
                    for (int i = tamanho - 1; i >= 1; i--)
                    {
                        for (int j = 1; j <= tamanho - i; j++)
                            resultado += " ";
                        for (int j = 1; j <= 2 * i - 1; j++)
                            resultado += "%";
                        resultado += "\n";
                    }
                }

                lblRes.Text = $"Res:\n{resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite valores válidos";
            }
        }
    }
}





