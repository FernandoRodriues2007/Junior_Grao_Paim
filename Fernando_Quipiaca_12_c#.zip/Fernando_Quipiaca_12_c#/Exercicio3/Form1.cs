﻿using System;
using System.Windows.Forms;

namespace Exercicio3
{
    public partial class Form1 : Form
    {
        private TextBox txtX, txtY, txtZ;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 3";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblX = new Label();
            lblX.Text = "X:";
            lblX.Location = new System.Drawing.Point(20, 20);
            lblX.Size = new System.Drawing.Size(100, 20);

            txtX = new TextBox();
            txtX.Location = new System.Drawing.Point(130, 20);
            txtX.Size = new System.Drawing.Size(150, 20);

            Label lblY = new Label();
            lblY.Text = "Y:";
            lblY.Location = new System.Drawing.Point(20, 50);
            lblY.Size = new System.Drawing.Size(100, 20);

            txtY = new TextBox();
            txtY.Location = new System.Drawing.Point(130, 50);
            txtY.Size = new System.Drawing.Size(150, 20);

            Label lblZ = new Label();
            lblZ.Text = "Z:";
            lblZ.Location = new System.Drawing.Point(20, 80);
            lblZ.Size = new System.Drawing.Size(100, 20);

            txtZ = new TextBox();
            txtZ.Location = new System.Drawing.Point(130, 80);
            txtZ.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 120);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 170);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lblX);
            this.Controls.Add(txtX);
            this.Controls.Add(lblY);
            this.Controls.Add(txtY);
            this.Controls.Add(lblZ);
            this.Controls.Add(txtZ);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int x = int.Parse(txtX.Text);
                int y = int.Parse(txtY.Text);
                int z = int.Parse(txtZ.Text);

                if (x + y > z && x + z > y && y + z > x)
                {
                    if (x == y && y == z)
                        lblRes.Text = "Res: Triângulo Equilátero";
                    else if (x == y || x == z || y == z)
                        lblRes.Text = "Res: Triângulo Isósceles";
                    else
                        lblRes.Text = "Res: Triângulo Escaleno";
                }
                else
                {
                    lblRes.Text = "Res: Não formam um triângulo";
                }
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite números válidos";
            }
        }
    }
}





