﻿using System;
using System.Windows.Forms;

namespace Exercicio39
{
    public partial class Form1 : Form
    {
        private TextBox txtN1, txtN2;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 39";
            this.Size = new System.Drawing.Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "Número 1:";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtN1 = new TextBox();
            txtN1.Location = new System.Drawing.Point(130, 20);
            txtN1.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "Número 2:";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtN2 = new TextBox();
            txtN2.Location = new System.Drawing.Point(130, 50);
            txtN2.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 90);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 140);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtN1);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtN2);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int num1 = int.Parse(txtN1.Text);
                int num2 = int.Parse(txtN2.Text);
                int resultado = 0;
                for (int i = 0; i < num2; i++)
                {
                    resultado += num1;
                }
                lblRes.Text = $"Res: {resultado}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite números válidos";
            }
        }
    }
}





