﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Exercicio9
{
    public partial class Form1 : Form
    {
        private Button btnIni;
        private TextBox txtN;
        private Label lblAv, lblRes;
        private sw sw;
        private Random random;
        private int numAleat;

        public Form1()
        {
            InitializeComponent();
            random = new Random();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 9";
            this.Size = new System.Drawing.Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            btnIni = new Button();
            btnIni.Text = "Iniciar";
            btnIni.Location = new System.Drawing.Point(20, 20);
            btnIni.Size = new System.Drawing.Size(100, 30);
            btnIni.Click += btnIni_Click;

            lblAv = new Label();
            lblAv.Text = "Aguardando";
            lblAv.Location = new System.Drawing.Point(20, 70);
            lblAv.Size = new System.Drawing.Size(350, 30);
            lblAv.Font = new System.Drawing.Font("Arial", 12, System.Drawing.FontStyle.Bold);

            Label lblNum = new Label();
            lblNum.Text = "Digite o número:";
            lblNum.Location = new System.Drawing.Point(20, 110);
            lblNum.Size = new System.Drawing.Size(120, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(150, 110);
            txtN.Size = new System.Drawing.Size(100, 20);
            txtN.Enabled = false;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 150);
            lblRes.Size = new System.Drawing.Size(350, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(btnIni);
            this.Controls.Add(lblAv);
            this.Controls.Add(lblNum);
            this.Controls.Add(txtN);
            this.Controls.Add(lblRes);
        }

        private void btnIni_Click(object sender, EventArgs e)
        {
            btnIni.Enabled = false;
            txtN.Enabled = false;
            txtN.Text = "";
            lblAv.Text = "Aguardando";
            lblRes.Text = "Res:";

            Timer t = new Timer();
            timer.Interval = random.Next(1000, 5000);
            timer.Tick += (s, args) =>
            {
                timer.Stop();
                numAleat = random.Next(1, 100);
                lblAv.Text = $"Digite: {numAleat}";
                sw = sw.StartNew();
                txtN.Enabled = true;
                txtN.Focus();
                txtN.KeyDown += txtN_KeyDown;
            };
            timer.Start();
        }

        private void txtN_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    int n = int.Parse(txtN.Text);
                    if (num == numAleat)
                    {
                        sw.Stop();
                        double t = sw.ElapsedMilliseconds / 1000.0;
                        lblRes.Text = $"Res: Tempo de reação: {tempo:F2} seg";
                    }
                    else
                    {
                        lblRes.Text = "Res: Número incorreto!";
                    }
                    txtN.Enabled = false;
                    btnIni.Enabled = true;
                    txtN.KeyDown -= txtN_KeyDown;
                }
                catch
                {
                    lblRes.Text = "Res: Digite um número válido";
                }
            }
        }
    }
}





