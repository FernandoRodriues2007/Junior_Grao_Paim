﻿using System;
using System.Windows.Forms;

namespace Exercicio88
{
    public partial class Form1 : Form
    {
        private TextBox txtFrase;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 88";
            this.Size = new System.Drawing.Size(500, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl = new Label();
            lbl.Text = "Frase:";
            lbl.Location = new System.Drawing.Point(20, 20);
            lbl.Size = new System.Drawing.Size(100, 20);

            txtFrase = new TextBox();
            txtFrase.Location = new System.Drawing.Point(130, 20);
            txtFrase.Size = new System.Drawing.Size(330, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 60);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 110);
            lblRes.Size = new System.Drawing.Size(450, 50);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl);
            this.Controls.Add(txtFrase);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text;
            string res = "";
            for (int i = 0; i < frase.Length; i++)
            {
                resultado += frase[i];
                resultado += frase[i];
            }
            lblRes.Text = $"Res: {resultado}";
        }
    }
}





