﻿using System;
using System.Windows.Forms;

namespace Exercicio55
{
    public partial class Form1 : Form
    {
        private TextBox txtN, txtA1, txtR;
        private Button btnOk;
        private Label lblRes;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Exercício 55";
            this.Size = new System.Drawing.Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lbl1 = new Label();
            lbl1.Text = "N (termos):";
            lbl1.Location = new System.Drawing.Point(20, 20);
            lbl1.Size = new System.Drawing.Size(100, 20);

            txtN = new TextBox();
            txtN.Location = new System.Drawing.Point(130, 20);
            txtN.Size = new System.Drawing.Size(150, 20);

            Label lbl2 = new Label();
            lbl2.Text = "A1 (primeiro termo):";
            lbl2.Location = new System.Drawing.Point(20, 50);
            lbl2.Size = new System.Drawing.Size(100, 20);

            txtA1 = new TextBox();
            txtA1.Location = new System.Drawing.Point(130, 50);
            txtA1.Size = new System.Drawing.Size(150, 20);

            Label lbl3 = new Label();
            lbl3.Text = "R (razão):";
            lbl3.Location = new System.Drawing.Point(20, 80);
            lbl3.Size = new System.Drawing.Size(100, 20);

            txtR = new TextBox();
            txtR.Location = new System.Drawing.Point(130, 80);
            txtR.Size = new System.Drawing.Size(150, 20);

            btnOk = new Button();
            btnOk.Text = "Ok";
            btnOk.Location = new System.Drawing.Point(20, 120);
            btnOk.Size = new System.Drawing.Size(100, 30);
            btnOk.Click += btnOk_Click;

            lblRes = new Label();
            lblRes.Text = "Res:";
            lblRes.Location = new System.Drawing.Point(20, 170);
            lblRes.Size = new System.Drawing.Size(450, 200);
            lblRes.AutoSize = false;

            this.Controls.Add(lbl1);
            this.Controls.Add(txtN);
            this.Controls.Add(lbl2);
            this.Controls.Add(txtA1);
            this.Controls.Add(lbl3);
            this.Controls.Add(txtR);
            this.Controls.Add(btnOk);
            this.Controls.Add(lblRes);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtN.Text);
                double a1 = double.Parse(txtA1.Text);
                double r = double.Parse(txtR.Text);
                string termos = "";
                double s = 0;
                double termo = a1;

                for (int i = 0; i < n; i++)
                {
                    if (termos != "") termos += ", ";
                    termos += termo;
                    soma += termo;
                    termo += r;
                }

                lblRes.Text = $"Res:\nTermos: {termos}\nSoma: {soma}";
            }
            catch
            {
                lblRes.Text = "Res: Erro - Digite números válidos";
            }
        }
    }
}





