let lista = []

for(let i = 1; i <= 5; i++){
  let num = Number(prompt("n" + i))
  lista.push(num)
}

lista.sort((a,b)=>a-b)
console.log("ordem crescente:", lista)
lista.sort((a,b)=>b-a)
console.log("ordem decrescente:", lista)
console.log("maior:", Math.max(...lista))
console.log("menor:", Math.min(...lista))