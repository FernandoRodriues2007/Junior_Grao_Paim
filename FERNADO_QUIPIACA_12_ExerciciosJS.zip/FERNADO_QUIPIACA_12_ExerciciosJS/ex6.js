let a = Number(prompt("nota1"))
let b = Number(prompt("nota2"))
let c = Number(prompt("nota3"))
let media = (a+b+c)/3
if(media >= 7){
  console.log("aprovado")
}else if(media >=5){
  console.log("recuperação")
}else{
  console.log("reprovado")
}