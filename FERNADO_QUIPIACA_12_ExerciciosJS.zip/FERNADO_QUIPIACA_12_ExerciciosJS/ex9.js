let secreto = Math.floor(Math.random()*20)+1
let chute = 0
while(chute != secreto){
  chute = Number(prompt("adivinha o numero"))
  if(chute > secreto){
    console.log("menor")
  }else if(chute < secreto){
    console.log("maior")
  }else{
    console.log("acertou")
  }
}