let email = prompt("digita teu email")
if(email.includes("@") && email.includes(".")){
  console.log("email bom")
}else{
  console.log("email errado")
}
