let inicio = Number(prompt("inicio"))
let fim = Number(prompt("fim"))
for(let i = inicio; i <= fim; i++){
  if(i % 2 == 0){
    console.log(i, "é par")
  }else{
    console.log(i, "é impar")
  }
}