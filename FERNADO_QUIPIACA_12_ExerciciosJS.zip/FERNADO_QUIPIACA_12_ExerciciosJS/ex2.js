let nome = prompt("nome:")
let peso = prompt("peso:")
let altura = prompt("altura:")
let imc = peso / (altura * altura)
if(imc < 18.5){
  console.log("abaixo do peso")
}else if(imc < 25){
  console.log("normal")
}else if(imc < 30){
  console.log("sobrepeso")
}else{
  console.log("obeso")
}