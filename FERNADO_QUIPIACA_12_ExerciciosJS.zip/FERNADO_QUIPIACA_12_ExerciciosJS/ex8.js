let pessoas = []
let nome1 = prompt("nome:")
let idade1 = prompt("idade:")
let cidade1 = prompt("cidade:")
pessoas.push({nome:nome1,idade:idade1,cidade:cidade1})
console.log(pessoas)
