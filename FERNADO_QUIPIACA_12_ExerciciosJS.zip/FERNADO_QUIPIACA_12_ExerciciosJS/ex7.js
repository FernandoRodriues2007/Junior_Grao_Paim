let v = Number(prompt("valor"))
let c100 = Math.floor(v/100)
v = v%100
let c50 = Math.floor(v/50)
v = v%50
let c20 = Math.floor(v/20)
v = v%20
let c10 = Math.floor(v/10)
console.log("100:",c100,"50:",c50,"20:",c20,"10:",c10)